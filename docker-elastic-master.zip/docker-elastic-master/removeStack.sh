#!/bin/bash

docker stack rm elastic
