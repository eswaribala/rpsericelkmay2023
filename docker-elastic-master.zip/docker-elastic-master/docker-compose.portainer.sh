#!/bin/bash

docker stack deploy --compose-file=docker-compose.portainer.yml portainer
